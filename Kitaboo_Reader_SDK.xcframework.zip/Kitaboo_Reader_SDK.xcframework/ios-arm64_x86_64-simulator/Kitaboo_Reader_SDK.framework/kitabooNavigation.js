// Jump to href location

//function loadHref(inputhref1){
//    
//    var top = document.getElementById(inputhref1);
//    var highlightOffSet = parseInt(top.offsetTop);
////           alert("top  " + highlightOffSet + "id  "+ inputhref1);
//    topMargin = highlightOffSet;
//
//    var docWidth = window.innerWidth;
//    var docHeight = window.innerHeight;
//    var leftOffSet = 5;
//    var pageNumber = Math.ceil(parseInt(highlightOffSet)/docHeight);
//    var leftMargin = ((pageNumber-1)*docWidth) + leftOffSet;
//
//    var topMargin = 0;
////    alert("scrollEnabled "+scrollEnabled);
//    if(scrollEnabled == "false")
//    {
////        alert("top  " + highlightOffSet + "id  "+ inputhref1);
//
//        leftMargin = 0;
//        topMargin = highlightOffSet;
//    }
//    
//    window.scrollTo(leftMargin, topMargin);
//}

// Scroll to top

function scrollTop(x,y){ window.scrollTo(x, y); }





