//
//  CategoryInfo+CoreDataClass.h
//  Kitaboo
//
//  Created by Mandar Choudhary on 26/03/20.
//  Copyright © 2020 Hurix System. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class HDBookInfo, NSObject;

NS_ASSUME_NONNULL_BEGIN

@interface CategoryInfo : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CategoryInfo+CoreDataProperties.h"
