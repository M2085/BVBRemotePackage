//
//  HDUserSettings+CoreDataClass.h
//  Kitaboo 5.0
//
//  Created by Rajat.Babhulgaonkar on 05/04/19.
//  Copyright © 2019 Hurix System. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class NSObject;

NS_ASSUME_NONNULL_BEGIN

@interface HDUserSettings : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "HDUserSettings+CoreDataProperties.h"
