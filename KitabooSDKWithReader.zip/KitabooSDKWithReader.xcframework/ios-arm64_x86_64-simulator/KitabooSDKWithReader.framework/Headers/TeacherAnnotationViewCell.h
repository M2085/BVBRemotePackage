//
//  TeacherAnnotationViewCell.h
//  Kitaboo
//
//  Created by Hurix System on 26/07/18.
//  Copyright © 2018 Hurix System. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeacherAnnotationViewCell : UICollectionViewCell
@property (nonatomic, strong) UILabel *classButton;
@end
